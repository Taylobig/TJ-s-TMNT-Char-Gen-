
function rollDice(num, sides) {
  let total = 0;
  for (let i = 0; i < num; i++) {
    total += Math.floor(Math.random() * sides) + 1;
  }
  return total;
}

function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generateCharacter() {
  const species = randomChoice(["Mutant Turtle", "Mutant Skunk", "Mutant Cat", "Mutant Alligator", "Mutant Eagle"]);
  const background = randomChoice(["Escaped Lab Hero", "Streetwise Fighter", "Wild Adventure Kid", "Friendly Pet Gone Mutant"]);
  const occupation = randomChoice(["Crime-Fighter", "Super-Spy", "Explorer", "Mystery Solver", "Pizza Delivery Hero"]);
  const alignment = randomChoice(["Good Guy", "Friendly Trickster", "Noble Adventurer", "Silly Hero"]);

  const attributes = {
    IQ: rollDice(3, 6),
    ME: rollDice(3, 6),
    MA: rollDice(3, 6),
    PS: rollDice(3, 6) + 4,
    PP: rollDice(3, 6),
    PE: rollDice(3, 6) + 2,
    PB: rollDice(3, 6),
    Spd: rollDice(3, 6)
  };

  document.getElementById('character-card').innerHTML = `
    <h2>Yay! Here's Your Hero!</h2>
    <p><strong>Animal Type:</strong> ${species}</p>
    <p><strong>Story:</strong> ${background}</p>
    <p><strong>Hero Job:</strong> ${occupation}</p>
    <p><strong>Personality:</strong> ${alignment}</p>
    <h3>Super Skills:</h3>
    <ul style="list-style:none;padding:0;font-size:18px;">
      <li><strong>Smarts (IQ):</strong> ${attributes.IQ}</li>
      <li><strong>Bravery (ME):</strong> ${attributes.ME}</li>
      <li><strong>Charm (MA):</strong> ${attributes.MA}</li>
      <li><strong>Strength (PS):</strong> ${attributes.PS}</li>
      <li><strong>Speedy Moves (PP):</strong> ${attributes.PP}</li>
      <li><strong>Stamina (PE):</strong> ${attributes.PE}</li>
      <li><strong>Cool Looks (PB):</strong> ${attributes.PB}</li>
      <li><strong>Running Fast (Spd):</strong> ${attributes.Spd}</li>
    </ul>
  `;

  unmuteMusic();
}

function autoPlayMusic() {
  const music = document.getElementById("theme-song");
  music.play();
}

function playMusic() {
  const music = document.getElementById("theme-song");
  music.muted = false;
  music.play();
}

function unmuteMusic() {
  const music = document.getElementById("theme-song");
  music.muted = false;
}
